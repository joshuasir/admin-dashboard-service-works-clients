<div class="initcontainer container mt-2" id="clients" >
    <div class="row">
        <?php if(Auth::user()->is_admin == 1): ?>
        <form class="w-75" method="post" action="<?php echo e(action('App\Http\Controllers\ClientController@store')); ?>" enctype="multipart/form-data">
            <?php echo method_field('post'); ?>

            <?php echo csrf_field(); ?>
            
            <h3 class="">Upload a Client</h3>
            <div class="form-group mb-4 mt-3">
                <input name="clientImage" class="clientsrc form-control" type="file">
                
                
            
            <select class="form-control mb-3 mt-2" name="size">
                <option value="small"> Small</option>
                <option value="mid">Medium</option>
                <option value="large">Large</option>
            </select>
            <button type="submit" class="input-group-text border-0 btn-primary">
                Submit 
                </button>
            </div>
        </form>
        <?php endif; ?>
        <?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(isset($clients) && count($clients) > 0): ?>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <img class="card-img-top" alt="Thumbnail [100%x225]" style="height: max(100px);width: max(120px)" src="../storage/clients/<?php echo e($client->Source); ?>" data-holder-rendered="true">
                <div class="card-body">
                    <p class="card-text"><?php echo e($client->ClientName); ?></p>
                    <small class="text-muted"><?php echo e($client->updated_at); ?></small>
                    <?php if(Auth::user()->is_admin == 1): ?>
                    <div>
                    <form method="post" style="display: inline;" action="<?php echo e(action('App\Http\Controllers\ClientController@destroy',[$client->id])); ?>">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                    <form method="post" style="display: inline;" action=<?php echo e(action('App\Http\Controllers\ClientController@updateVisibility',[$client->id])); ?>>
                        <?php echo method_field('post'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-<?php echo e($client->Visible ? 'secondary':'outline-secondary'); ?> fav">
                        <?php if($client->Visible): ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                          <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                          <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                        </svg>
                        <?php else: ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">
                          <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
                          <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>
                          <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>
                        </svg>
                        <?php endif; ?>
                          
                      </button>
                      </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <p> No work client yet at this moment.</p>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\xampp\htdocs\lalunams\resources\views/clients.blade.php ENDPATH**/ ?>