

<?php $__env->startSection('script'); ?>
<script>
$(function(){
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#add').on('click',function(){
        if($('#addForm').css('display')==='none'){
            
            $(this).text('Cancel');
            $('#addForm').css('display','initial');
            $(this).attr('class',"ml-auto btn btn-info text-white bg-danger");
        }else{
            $(this).text('Add');
            $('#addForm').css('display','none');
            $(this).attr('class',"ml-auto btn btn-info text-white bg-success");
        }
        
    })
    $('li.workitem:not(div.btn-group)').on('click',function(){
        if($('#addForm').css('display')==='none'){
            $('#add').click()[0];

        }
        $("html,body").animate({ scrollTop: $('#add').offset().top }, 500);
        let id = $(this).attr('key');
        let loc = 'li[key='.concat(id).concat('] ');
        let img = $(loc.concat('img')).attr('src');
        let tag = $(loc.concat('span > .tag')).text();
        let link = $(loc.concat('span > .tag')).attr('href');
        let category = $(loc.concat('span > .category')).text().split(' ')[2];
        let type  =$(loc.concat('span > .type')).text().split(' ')[2];
        
        // alert($('li[key=24] span p.tag').text());
        $('.tag').val(tag);
        $('.link').val(link);
        $('#cat option[value="'.concat(category).concat('"]')).attr('selected',true);
        $('#type option[value="'.concat(type).concat('"]')).attr('selected',true);
        $('.id').val(id);
    })
    $('#searchbar').keypress(function (e) {
        if (e.which == 13) {
            $('#findword').click();
            return false;    //<---- Add this line
        }
        });
    $('#findword').on('click',function(){
        let keyword = $('#searchbar').val();
        // let cat = $('#select-cat option:selected').val();
        // $('#select-cat').prop('selectedIndex',0);
        // $.ajax({
        //     type: "post",
        //     url: '/findword/'.concat(keyword),
        //     success: function (response) {
        //         $('.lists').empty();
                
        //        response.works.data.forEach(work =>
        //        $('.lists').append(`<li key=${work.WorkID} type="button" class="main-row list-group-item list-group-item-action ">
        //             <img width="200px" height="200px" class="img-thumbnail image" src="../../../laluna/assets/works" alt="">
        //             <span>
        //                 <a href=${work.Link} class="w-50 tag">${work.Tag}</a>
        //                 <p class="w-50 category">Category : ${work.Category}</p>
        //                 <p class="w-50 type">Type : ${work.Type}</p>
        //                 <p class="text-muted w-75 last">${work.LastUpdated}</p>
        //             </span>
        //         </li>`)
        //        );
                
        //     }
        // });
    })
    let cat = $('#select-cat').attr('value');
    $('#select-cat option[value="'.concat(cat).concat('"]')).attr('selected',true);
    
    $('button.openEdit').on('click',function(){
      
      if($('#clientEdit').css('display')==='none'){
            
            $(this).text('Cancel');
            $('#clientEdit').show();
            $(this).attr('class',"btn btn-sm btn-outline-danger openEdit mb-4");
        }else{
            $(this).text('Add');
            $('#clientEdit').css('display','none');
            $(this).attr('class',"btn btn-sm btn-outline-secondary openEdit mb-4");
        }

    })
    $('div > button.fav').on('click',function(){
        let cat = $(this).attr('key');
        
        $.ajax({
            type: "put",
            url: '/works/'.concat(cat),
            success: function (response) {
              
            }
        });
        if($(this).attr('class')==='btn btn-outline-secondary fav'){
            $(this).attr('class',"btn btn-warning fav");
        }else{
            $(this).attr('class',"btn btn-outline-secondary fav");
        }
      })
    $('#select-cat').on('change',function(e){
        // $.ajax({
        //     type: "post",
        //     url: '/index/'.concat(cat),
        //     success: function (response) {
        //         $('.lists').empty();
                
        //        response.works.data.forEach(work =>
        //        $('.lists').append(`<li key=${work.WorkID} type="button" class="main-row list-group-item list-group-item-action ">
        //             <img width="200px" height="200px" class="img-thumbnail image" src="../../../laluna/assets/works" alt="">
        //             <span>
        //                 <a href=${work.Link} class="w-50 tag">${work.Tag}</a>
        //                 <p class="w-50 category">Category : ${work.Category}</p>
        //                 <p class="w-50 type">Type : ${work.Type}</p>
        //                 <p class="text-muted w-75 last">${work.LastUpdated}</p>
        //             </span>
        //         </li>`)
        //        );
                
        //     }
        // });
    });

})
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body class="antialiased">
    <div class="album py-5 bg-light">
        <div class="container" id="works">
            <form action="<?php echo e(url('/index')); ?>" method="get" id="form1">
              <?php echo e(csrf_field()); ?>

              <div class="form-groups">
                <h3 for="category"> Select Category to Search on</h3>
                <select class="form-control mb-3" name="categoryopt" id="select-cat" value="<?php echo e($category); ?>">
                  <option value="%">All</option>
                  <option value="event">Travel & Event </option>
                  <option value="movies"> Film & Web Series</option>
                  <option value="fotografi"> Product Commercial</option>
                  <option value="prop">Company Profile</option>
                  <option value="music">Music Video</option>
                  <option value="live">Live Stream</option>
              </select>
              </div>
              <div class="form-groups">
                
                <div class="input-group rounded pt-2">
                  <input name="searchbar" value="<?php echo e($keyword); ?>" type="search" class="form-control rounded" placeholder="Search Keyword" id="searchbar" aria-label="Search"
                  aria-describedby="search-addon" />
                  
                  <button type="submit" class="input-group-text border-0 btn-secondary" id="findword">
                    Find 
                  </button>
                  
                  <button id="add" class="ml-auto btn btn-info text-white bg-success" type="button"> Add </button>
              </div>
              </div>
                
                
            </form>
            
            <form id="addForm" style="display: none" class="w-75" method="post" action="<?php echo e(action('App\Http\Controllers\WorksController@store')); ?>" enctype="multipart/form-data">
              <?php echo method_field('post'); ?>

              <?php echo csrf_field(); ?>
              
              <h3 class="pt-4">Upload/Edit a Work</h3>
              <input name="WorkID"type="text" value='-1' style="display:none;" class="id">
                <input name="Tag" class="tag form-control mb-3" type="text" placeholder="title">
                <input name="Link" class="link form-control mb-3" type="text" placeholder="link">
                <input name="Source" id="formFile" class="source form-control mb-3" type="file">
                <select name="CategoryAdd" class="form-control mb-3" id="cat">
                    <option class="text-muted" value="%">-- pick category --</option>
                    <option value="event">Travel & Event</option>
                    <option value="movies"> Film & Web Series</option>
                    <option value="fotografi"> Product Commercial</option>
                    <option value="prop">Company Profile</option>
                    <option value="music">Music Video</option>
                    <option value="live">Live Stream</option>
                </select>
                <select name="Type" class="form-control mb-3" name="type" id="type">
                    <option value="video">Video</option>
                    <option value="image">Image</option>
                </select>
                <input class="btn bg-primary" style="color: white" type="submit" value="submit">
                
              </form>
              <?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <ol class="list-group m-4 lists" >
              <?php if(isset($works) && count($works) > 0): ?>
              <?php echo e($works->links()); ?>

              <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  <li key=<?php echo e($work->WorkID); ?> type="button" style="list-style-position: inside;"class="workitem list-group-item list-group-item-action flex-row " >
                      
                    <img width="200px" height="200px" class="img-thumbnail image" src="storage/works/<?php echo e($work->Category); ?>/<?php echo e($work->Source); ?>" alt="">
                    
                    <span class="list-group">
                          <a href=<?php echo e($work->Link); ?> target='_blank' class="w-50 tag btn-link"><?php echo e($work->Tag); ?> </a>
                          
                          <span class="w-50 category">Category : <?php echo e($work->Category); ?> </span>
                          
                          <span class="w-50 type">Type : <?php echo e($work->Type); ?></span>
                          
                          <span class="text-muted w-75 last"><?php echo e($work->LastUpdated); ?></span>
                        </span>
                  </li>
                  <div key=<?php echo e($work->WorkID); ?> class="flex-row justify-content-between w-100 work-btn container-fluid p-2">
                    <button key=<?php echo e($work->WorkID); ?> type="button" class="btn btn-<?php echo e($work->Highlight ? 'warning':'outline-secondary'); ?> fav">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star" viewBox="0 0 16 17">
                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z"/>
                      </svg> 
                    
                    </button>
                    <button key=<?php echo e($work->WorkID); ?> type="button" class="btn btn-outline-danger">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
                      </svg>
                      Delete
                    </button>
                  </div>  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($works->links()); ?>

              <?php else: ?>
              <p> No work posted yet at this moment.</p>
              <?php endif; ?>
              </ol>
        </div>

        <div class="container mt-5">
          <div class="row">
            <?php if(isset($clients) && count($clients) > 0): ?>
              <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img class="card-img-top" alt="Thumbnail [100%x225]" style="height: 225px; width: 100%; display: block;" src="storage/clients/<?php echo e($client->Source); ?>" data-holder-rendered="true">
                  <div class="card-body">
                    <p class="card-text"><?php echo e($client->ClientName); ?></p>
                    <button type="button" class="btn btn-sm btn-outline-secondary openEdit" >Edit</button>
                    <div class="d-flex justify-content-between align-items-center">
                      
                        
                        
                        <form action="post" style="display: none;" id ="clientEdit">
                          <input name="ClientSource" class="form-control mb-3" type="file">
                          <input class="btn bg-primary" style="color: white" type="submit" value="submit">
                        </form>
                   
                      <small class="text-muted"><?php echo e($client->updated_at); ?></small>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <p> No work client yet at this moment.</p>
              <?php endif; ?>
          </div>
        </div>
      </div>

    </div>
</body>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lalunams\resources\views//index.blade.php ENDPATH**/ ?>