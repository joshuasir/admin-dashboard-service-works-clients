

<?php $__env->startSection('content'); ?>

<div class="container-fluid d-flex flex-column mw-25 align-items-center pt-5">
    <img src="" alt="">
    <h3> Laluna Log in</h3>
    <form class="w-25" method="post">
        <div class="form-group mb-3">
          <input type="text" class="form-control" id="Email" aria-describedby="emailHelp" placeholder="Username or Email">
               </div>
        <div class="form-group mb-3">
          <input type="password" class="form-control" id="Password" placeholder="Password">
        </div>
        <div class="form-group pb-4 text-center d-flex flex-column">
            <button type="submit" class="btn btn-primary mb-2">Log in</button>
            
        </div>
        
      </form>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lalunams\resources\views/login.blade.php ENDPATH**/ ?>