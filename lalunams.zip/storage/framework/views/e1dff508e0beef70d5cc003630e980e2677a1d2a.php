

<?php $__env->startSection('listWorks'); ?>
<ol class="list-group m-4" >
    <?php if(isset($works) && count($works) > 0): ?>
    <?php echo e($works->links()); ?>

    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li key=<?php echo e($work->WorkID); ?> type="button" class="main-row list-group-item list-group-item-action ">
            <img width="200px" height="200px" class="img-thumbnail image" src="../../../laluna/assets/works/<?php echo e($work->Category); ?>/<?php echo e($work->Source); ?>.jpg" alt="">
            <span>
                <p class="w-50 tag"><?php echo e($work->Tag); ?></p>
                <p class="w-50 category">Category : <?php echo e($work->Category); ?></p>
                <p class="w-50 type">Type : <?php echo e($work->Type); ?></p>
                <p class="text-muted w-75 last"><?php echo e($work->LastUpdated); ?></p>
            </span>
        </li>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($works->links()); ?>

    <?php else: ?>
    <p> No work posted yet at this moment.</p>
    <?php endif; ?>
</ol>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lalunams\resources\views/listWorks.blade.php ENDPATH**/ ?>